//==================================================================================
// Copyright (c) 2016 , Advanced Micro Devices, Inc.  All rights reserved.
//
/// \author AMD Developer Tools Team
/// \file AMDTSmu9CounterTable.h
///
//==================================================================================

#ifndef _AMDT_SMU9_COUNTER_TABLE_H_
#define _AMDT_SMU9_COUNTER_TABLE_H_


// LOCAL INCLUDES
#include <AMDTDriverTypedefs.h>

typedef struct PwrSmu9CounterTable
{                 
} PwrSmu9CounterTable;

#endif // _AMDT_SMU9_COUNTER_TABLE_H_

